/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;
import Clases.Cliente;
import Clases.Counter;
import Clases.TipoCambio;
import java.util.Date;
import java.util.Scanner;
/**
 *
 * @author JOSUE
 */

public class ProyectoPOO {

    /**
     * @param args the command line arguments
     * */
    
    public static void main(String[] args) {
        /*
        Counter counter1 = new Counter("123", "Manfred", "Juan Viñas", 3);
        counter1.registrarCliente();
        
        counter1.agregarEntregableCounter();
        
        counter1.consultarCliente();
        
        */
        /*
        double[] tiposCambio = TipoCambio.consulta();

        // Almacenar los valores de compra y venta en variables separadas
        double tipoCambioCompra = tiposCambio[0];
        double tipoCambioVenta = tiposCambio[1];

        // Imprimir los valores por separado
        System.out.println("Tipo de cambio de compra (USD): " + tipoCambioCompra);
        System.out.println("Tipo de cambio de venta (USD): " + tipoCambioVenta);
        */
        /*--------------------------------------------
        ELIMINAR CLIENTE Y CONSULTAR CLIENTES
        ----------------------------------------------
        Cliente cliente1 = new Cliente("1", "Juan", "juan@mail.com", "123456", "M", new Date(), null);
        Cliente cliente2 = new Cliente("2", "Maria", "maria@mail.com", "654321", "F", new Date(), null);
        Cliente cliente3 = new Cliente("3", "David", "david@mail.com", "012654", "M", new Date(), null);
        
        Cliente.agregarCliente(cliente1);
        Cliente.agregarCliente(cliente2);
        Cliente.agregarCliente(cliente3);
        
        // Mostrar los clientes antes de eliminar
        System.out.println("Clientes antes de eliminar:");
        for (Cliente cliente : Cliente.getListaClientes()) {
            System.out.println(cliente);
        }
        
        // Pedir al usuario el ID del cliente que desea eliminar
        Scanner scanner = new Scanner(System.in);
        System.out.println("3. Eliminar ");
        System.out.println("4. Consultar ");
        System.out.print("Ingrese el numero que quiera consultar: ");
        int opcion = Integer.parseInt(scanner.nextLine());
        
        if (opcion==3){
        
            System.out.print("Ingrese el ID del cliente que desea eliminar: ");
            String id = scanner.nextLine();

            // Eliminar el cliente con el ID proporcionado
            Cliente clienteAEliminar = null;
            for (Cliente cliente : Cliente.getListaClientes()) {
                if (cliente.getId().equals(id)) {
                    clienteAEliminar = cliente;
                    break;
                }
            }

            if (clienteAEliminar != null) {
                // Mostrar los detalles del cliente a eliminar y pedir confirmación
                System.out.println("Cliente encontrado: ");
                System.out.println(clienteAEliminar);
                System.out.print("¿Esta seguro que desea eliminar este cliente? (S/N): ");
                String confirmacion = scanner.nextLine().trim().toUpperCase();

                if (confirmacion.equals("S")) {
                    boolean eliminado = Cliente.eliminar(id);
                    if (eliminado) {
                        System.out.println("Cliente con ID " + id + " eliminado correctamente.");
                    }
                } else {
                    System.out.println("Eliminacion cancelada.");
                }
            } else {
                System.out.println("Cliente con ID " + id + " no encontrado.");
            }

            // Mostrar los clientes después de eliminar
            System.out.println("Clientes despues de eliminar:");
            for (Cliente cliente : Cliente.getListaClientes()) {
                System.out.println(cliente);
            }

            scanner.close();
        }
        else if (opcion==4){
            System.out.println("Lista Clientes: ");
            Cliente.consulta();
        }
        else{
            System.out.println("Seleccion invalida.");
        }
        */
        
        
     /* ------------------------------------------------
        PRUEBAS REGISTRO CLIENTE Y MODIFICAR CLIENTE
        ------------------------------------------------
        
        
        Scanner scanner = new Scanner(System.in); // Crear un objeto Scanner

        int numClientes = 2;

        for (int i = 0; i < numClientes; i++) {
            System.out.println("Registro del Cliente " + (i + 1) + ":");
            Cliente cliente = new Cliente(); // Usar el constructor vacío
            cliente.registrar(scanner); // Pasar el Scanner al método registrar

            // Mostrar la información del cliente registrado
            System.out.println(cliente);
            System.out.println(); // Línea en blanco para mejor legibilidad
        }

        // Acceder a la información del primer cliente registrado
        if (!Cliente.getListaClientes().isEmpty()) {
            Cliente cliente = Cliente.getListaClientes().get(1); // Obtener el primer cliente
            System.out.println("Información del primer cliente registrado:");
            System.out.println(cliente);
        }
        else {
            System.out.println("No hay clientes registrados.");
        }
        
        Cliente cliente = Cliente.getListaClientes().get(1); // Obtener el primer cliente
        cliente.modificar(scanner);
        System.out.println(cliente);

        scanner.close(); // Cerrar el Scanner al final
*/
    }
}
    
