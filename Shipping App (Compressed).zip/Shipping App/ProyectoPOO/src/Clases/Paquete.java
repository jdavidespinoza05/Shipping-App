/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.Calendar;
import java.text.SimpleDateFormat;

/**
 *
 * @author JOSUE
 */
public class Paquete extends Entregable{
    
    private boolean esFragil;
    private boolean esElectronico;
    private boolean esPeligroso;

    public Paquete() {
    }

    public Paquete(boolean esFragil, boolean esElectronico, boolean esPeligroso, String numReferencia, boolean estado, 
            String descripcion, String remitente, Calendar fechaEntrega, double peso) {
        
        super(numReferencia, estado, descripcion, remitente, fechaEntrega, peso);
        this.esFragil = esFragil;
        this.esElectronico = esElectronico;
        this.esPeligroso = esPeligroso;
    }

    public boolean isEsFragil() {
        return esFragil;
    }

    public void setEsFragil(boolean esFragil) {
        this.esFragil = esFragil;
    }

    public boolean isEsElectronico() {
        return esElectronico;
    }

    public void setEsElectronico(boolean esElectronico) {
        this.esElectronico = esElectronico;
    }

    public boolean isEsPeligroso() {
        return esPeligroso;
    }

    public void setEsPeligroso(boolean esPeligroso) {
        this.esPeligroso = esPeligroso;
    }
    
    @Override
    public double calcularImpuesto(){
        
        double impuesto = peso * 0.02;
        if (esElectronico)
            impuesto += 2;
        if (esFragil)
            impuesto += 2;
        
        return impuesto;
        
    }

    @Override
    public String toString() {
        return  "Paquete{" + super.toString() + "\n" +
                "esFragil=" + esFragil + "\n" +
                ", esElectronico=" + esElectronico + "\n" +
                ", esPeligroso=" + esPeligroso + '}';
    }
    
    
}

