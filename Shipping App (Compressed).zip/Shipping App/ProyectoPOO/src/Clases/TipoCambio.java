package Clases;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TipoCambio {
    public static double[] consulta() {
        String correo = "daniel22.viquez@gmail.com"; // Tu correo registrado
        String token = "0IIAC01LZN"; // Tu token

        // Obtener la fecha actual en formato dd/MM/yyyy
        String fechaActual = new SimpleDateFormat("dd/MM/yyyy").format(new Date());

        // Construcción de las URLs para la consulta (compra y venta)
        String apiUrlCompra = "https://gee.bccr.fi.cr/Indicadores/Suscripciones/WS/wsindicadoreseconomicos.asmx/ObtenerIndicadoresEconomicos?" +
                "Indicador=317&FechaInicio=" + fechaActual + "&FechaFinal=" + fechaActual +
                "&Nombre=N&SubNiveles=N&CorreoElectronico=" + correo + "&Token=" + token;

        String apiUrlVenta = "https://gee.bccr.fi.cr/Indicadores/Suscripciones/WS/wsindicadoreseconomicos.asmx/ObtenerIndicadoresEconomicos?" +
                "Indicador=318&FechaInicio=" + fechaActual + "&FechaFinal=" + fechaActual +
                "&Nombre=N&SubNiveles=N&CorreoElectronico=" + correo + "&Token=" + token;

        double tipoCambioCompra = realizarConsulta(apiUrlCompra, 317);
        double tipoCambioVenta = realizarConsulta(apiUrlVenta, 318);

        // Retornar los valores en un array
        return new double[]{tipoCambioCompra, tipoCambioVenta};
    }

    private static double realizarConsulta(String apiUrl, int indicador) {
        try {
            // Realizar la solicitud a la API
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            // Comprobar el código de respuesta
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) { // 200
                // Leer la respuesta
                BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String inputLine;
                StringBuilder response = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                in.close();

                // Imprimir el resultado (XML)
                System.out.println("Resultado de la consulta para indicador " + indicador + ":");
                System.out.println(response.toString());

                // Procesar el XML para obtener el valor
                return procesarXML(response.toString(), indicador);
            } else {
                System.out.println("Consulta fallida para indicador " + indicador + ". Código de respuesta: " + responseCode);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    private static double procesarXML(String xml, int indicador) {
        double tipoCambio = 0.0; // Valor por defecto
        try {
            // Extraer el valor del XML según el indicador
            String[] partes = xml.split("<INGC011_CAT_INDICADORECONOMIC");
            for (String parte : partes) {
                if (parte.contains("<COD_INDICADORINTERNO>" + indicador + "</COD_INDICADORINTERNO>")) {
                    int startIndex = parte.indexOf("<NUM_VALOR>") + "<NUM_VALOR>".length();
                    int endIndex = parte.indexOf("</NUM_VALOR>");
                    String valorString = parte.substring(startIndex, endIndex).trim();
                    tipoCambio = Double.parseDouble(valorString); // Convertir a double
                    break; // Salir del bucle una vez que se encuentra el valor
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tipoCambio; // Retornar el valor como double
    }
}
    

    

   