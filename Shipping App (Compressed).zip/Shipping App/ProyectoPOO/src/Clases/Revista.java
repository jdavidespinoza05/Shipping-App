/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.Calendar;
import java.text.SimpleDateFormat;

/**
 *
 * @author JOSUE
 */
public class Revista extends Entregable{
    
    private String nombre;
    private boolean esCatalogo;
    private String tematica;
    
    
    public Revista() {
    }

    public Revista(String nombre, boolean esCatalogo, String tematica, String numReferencia, boolean estado, String descripcion, String remitente, Calendar fechaEntrega, double peso) {
        super(numReferencia, estado, descripcion, remitente, fechaEntrega, peso);
        
        this.nombre = nombre;
        this.esCatalogo = esCatalogo;
        this.tematica = tematica;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isEsCatalogo() {
        return esCatalogo;
    }

    public void setEsCatalogo(boolean esCatalogo) {
        this.esCatalogo = esCatalogo;
    }
    

    public String getTematica() {
        return tematica;
    }

    public void setTematica(String tematica) {
        this.tematica = tematica;
    }
    
    @Override
    public double calcularImpuesto(){
        if (esCatalogo)
            return 0;
        return 1;
    }   

    @Override
    public String toString() {
        return "Revista{" + super.toString() + "\n" +
                "nombre=" + nombre + "\n" +
                ", tematica=" + tematica + '}';
    }

    
    
    
}
