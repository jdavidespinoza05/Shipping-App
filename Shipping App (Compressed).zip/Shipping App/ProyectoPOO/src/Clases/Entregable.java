/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;
import java.util.Calendar;
import java.text.SimpleDateFormat;

/**
 *
 * @author JOSUE
 */
public abstract class Entregable {
   
    protected String numReferencia;
    protected boolean estado; 
    protected String descripcion;
    protected String remitente;
    protected String metodoPago;
    protected Calendar fechaEntrega;
    protected double peso;
    protected double montoCobrado;  
    private Calendar fechaInsercion;

    public Entregable() {
        this.fechaInsercion = Calendar.getInstance();
    }
    
    public Entregable(String numReferencia){
        this.numReferencia = numReferencia;
        this.fechaInsercion = Calendar.getInstance();
    }

    public Entregable(String numReferencia, boolean estado, String descripcion, String remitente, Calendar fechaEntrega, double peso) {
        this.numReferencia = numReferencia;
        this.estado = estado;
        this.descripcion = descripcion;
        this.remitente = remitente;
        this.fechaEntrega = fechaEntrega;
        this.peso = peso;
        this.fechaInsercion = Calendar.getInstance();
    }

    public String getNumReferencia() {
        return numReferencia;
    }

    public void setNumReferencia(String numReferencia) {
        this.numReferencia = numReferencia;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }
    
    public double getMontoCobrado() {
        return montoCobrado;
    }

    public void setMontoCobrado(double montoCobrado) {
        this.montoCobrado = montoCobrado;
    }
 
    public String getRemitente() {
        return remitente;
    }

    public void setRemitente(String remitente) {
        this.remitente = remitente;
    }

    public Calendar getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Calendar fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
   
    public Calendar getFechaInsercion() {
        return fechaInsercion;
    }
    
    public abstract double calcularImpuesto();
    

    @Override
    public String toString() {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        String fechaFormatted = (fechaEntrega != null) ? formatoFecha.format(fechaEntrega.getTime()) : "No disponible";
        
        return String.format(" Entregable {\n" +
                "  numReferencia: %s\n" +
                "  Estado: %s\n" +
                "  Descripción: %s\n" +
                "  Remitente: %s\n" +
                "  FechaEntega: %s\n" +
                "  Monto de cobro: $%f\n" +
                "  Metodo de pago: %s\n" +
                "  Peso: %s\n" +
                "}",
                numReferencia,
                estado, 
                descripcion,
                remitente,
                fechaFormatted, 
                montoCobrado,
                metodoPago,
                peso);
    }
   
    
}
