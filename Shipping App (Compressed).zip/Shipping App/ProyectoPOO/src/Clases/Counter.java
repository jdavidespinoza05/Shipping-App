/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 *
 * @author JOSUE
 */
public class Counter {
    
    private String nombre;
    private String Cedula;
    private String direccion;
    private static ArrayList<Casillero> casilleros = new ArrayList<>(); 
    public static ArrayList<Cliente> listaClientes = new ArrayList<>();
    public static ArrayList<Counter> listaCounter = new ArrayList<>();
    
    public Counter(){
        
    }

    public Counter(String Cedula){
        this.Cedula = Cedula;
    }
    
    public Counter(String nombre, String Cedula, String direccion, int cantidadCasilleros) {
        this.nombre = nombre;
        this.Cedula = Cedula;
        this.direccion = direccion;
        
        for(int i = 0; i < cantidadCasilleros; i++)
        {
            casilleros.add(new Casillero(1000 + i));
        }
        
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return Cedula;
    }

    public void setCedula(String Cedula) {
        this.Cedula = Cedula;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
 
    public static Counter buscar(String Cedula) {
        for (Counter counter : listaCounter) {
            if (counter.Cedula.equals(Cedula)) {
                return counter;
            }
        }
        return null; // Retorna null si no se encuentra el counter
    }
    
    public static boolean existeCounter(String cedula) {
        return buscar(cedula) != null;
    }
    
    public static Counter registrarCounter()
    {
        String cedula, nombre, direccion, Casilleros;
        int cantidadCasilleros;
        // ID
        while (true) {
            String inputCedula = JOptionPane.showInputDialog(null, "Introduce la cédula:");
            if (inputCedula == null) {
                return null; // El usuario canceló
            }
            cedula = inputCedula;

            if (!cedula.matches("\\d+")) {
                JOptionPane.showMessageDialog(null, "Entrada inválida. Por favor, introduce solo números.");
            }

            Counter counter = buscar(cedula);

            if (counter == null){
                break;
            }else {
                JOptionPane.showMessageDialog(null, "Entrada inválida. La cedula del counter ya existe.");  
            }
        }
        
        nombre = JOptionPane.showInputDialog(null, "Introduce el Nombre:");
        if (nombre == null) return null; // El usuario canceló

        direccion = JOptionPane.showInputDialog(null, "Introduce la dirección:");
        if (direccion == null) return null; // El usuario canceló
        
        
        
        while (true) {
            Casilleros = JOptionPane.showInputDialog(null, "Introduce la cantidad de casilleros:");
            if (Casilleros == null) return null; // El usuario canceló

            if (!Casilleros.matches("\\d+")) {
                JOptionPane.showMessageDialog(null, "Entrada inválida. Por favor, introduce solo números.");
            }
            else{
                cantidadCasilleros = Integer.parseInt(Casilleros);
                break;
            }
        }
        
        Counter counter = new Counter(nombre, cedula, direccion, cantidadCasilleros);
        listaCounter.add(counter); 
        return counter;
    }
 
    
    
    public void registrarCliente()
    {
        
        Cliente cliente = new Cliente();
        boolean registrado = cliente.registrar(listaClientes);
        if (registrado){
            cliente.asignarCasillero(casilleros);
        }
    }
    
    public Cliente buscarCliente(String id) {
        return Cliente.buscar(id, listaClientes);
    }
    
    public void eliminarCliente()
    {
        Cliente.eliminarClienteGUI(listaClientes);
    }
    
    public void consultarCliente()
    {
        Cliente.consulta(listaClientes);
    }
    
    public void modificarCliente()
    {
        Cliente.modificar(listaClientes);
     
    }
    
    public void agregarEntregableCounter()
    {
        Cliente cliente1 = new Cliente();
        cliente1.agregarEntregable(listaClientes);
    }
    
    public void retirarArticulos()
    {
        TipoCambio tipoCambio = new TipoCambio();        
        Cliente.retirarArticulos(listaClientes, tipoCambio);
    }
   
    
    public void consultarEntregablesCounter() {
        Cliente.consultarEntregables(listaClientes);
    }
    
    public void consultarDetalleRetiroCounter() {
        Cliente.consultarDetalleRetiro(listaClientes);
    }
    
    public void consultarEstadoCasilleroCounter() {
        Cliente.consultarEstadoCasillero(listaClientes, casilleros);
    }
   
    public void MostrarEntregablesFechaCounter() {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        Calendar fechaBuscada = Calendar.getInstance();

        // Solicitar la fecha al usuario
        while (true) {
            String fechaInput = JOptionPane.showInputDialog(null, "Introduce la fecha (dd/MM/yyyy):");
            if (fechaInput == null) {
                return; // El usuario canceló
            }

            try {
                java.util.Date fecha = formatoFecha.parse(fechaInput);
                fechaBuscada.setTime(fecha);
                break; // Salir del bucle si la fecha es válida
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(null, "Formato de fecha inválido. Intente de nuevo.");
            }
        }

        // Recorrer todos los clientes y buscar entregables en la fecha indicada
        for (Cliente cliente : listaClientes) {
            cliente.buscarEntregablesPorFecha(fechaBuscada);
        }
    }
    
    public void mostrarPaquetesRetiradosPorFecha() {
    // Solicitar fecha de retiro
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        Calendar fechaBuscada = Calendar.getInstance();

        // Solicitar la fecha al usuario
        while (true) {
            String fechaInput = JOptionPane.showInputDialog(null, "Introduce la fecha (dd/MM/yyyy):");
            if (fechaInput == null) {
                return; // El usuario canceló
            }

            try {
                java.util.Date fecha = formatoFecha.parse(fechaInput);
                fechaBuscada.setTime(fecha);
                break; // Salir del bucle si la fecha es válida
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(null, "Formato de fecha inválido. Intente de nuevo.");
            }
        }

        // Recorrer todos los clientes y buscar entregables en la fecha indicada
        for (Cliente cliente : listaClientes) {
            cliente.buscarPaquetesRetiradosPorFecha(fechaBuscada);
        }
}
    public void mostrarResumenContable(Calendar fecha) {
        double totalRecaudado = 0;
        double totalImpuestos = 0;
        double descuentos = 0; // En este caso, siempre será 0.

        // Iterar sobre todos los clientes
        for (Cliente cliente : listaClientes) {
            for (Entregable entregable : cliente.getEntregables()) {
                // Comprobar si el entregable fue retirado el día especificado
                if (entregable.getFechaEntrega().get(Calendar.YEAR) == fecha.get(Calendar.YEAR) &&
                    entregable.getFechaEntrega().get(Calendar.MONTH) == fecha.get(Calendar.MONTH) &&
                    entregable.getFechaEntrega().get(Calendar.DAY_OF_MONTH) == fecha.get(Calendar.DAY_OF_MONTH)) {
                    
                    double impuesto = entregable.calcularImpuesto();
                    totalRecaudado += entregable.getMontoCobrado();
                    totalImpuestos += impuesto;
                }
            }
        }

        // Crear el mensaje a mostrar
        String mensaje = "Resumen Contable para " + fecha.get(Calendar.DAY_OF_MONTH) + "/" + 
                         (fecha.get(Calendar.MONTH) + 1) + "/" + fecha.get(Calendar.YEAR) + "\n" +
                         "Total Recaudado: " + totalRecaudado + "\n" +
                         "Total Impuestos: " + totalImpuestos + "\n" +
                         "Descuentos Aplicados: " + descuentos + "\n" +
                         "Monto Total: " + (totalRecaudado + totalImpuestos - descuentos);

        // Mostrar el mensaje en un cuadro de diálogo con scroll
        JTextArea textArea = new JTextArea(mensaje);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        JOptionPane.showMessageDialog(null, scrollPane, "Resumen Contable", JOptionPane.INFORMATION_MESSAGE);
    }

    public void listaClientesPaquetesP(){
        Cliente.ClientesPaquetesPendientes(listaClientes);
    }

    public void consultaArticulosP(){
        Cliente.ConsultaArticulosP(listaClientes);
    }

    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Counter other = (Counter) obj;
        return Objects.equals(this.Cedula, other.Cedula);
    }

    
    
    @Override
    public String toString() {
        return "Counter{" + "nombre=" + nombre + "\n" + 
                ", Cedula=" + Cedula + "\n"+ 
                ", direccion=" + direccion + "\n"+  
                ", casilleros=" + casilleros + "\n"+ 
                ", clientes=" + listaClientes + '}';
    }
    
    
    
}
