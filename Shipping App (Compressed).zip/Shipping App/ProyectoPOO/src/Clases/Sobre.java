/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.Calendar;
import java.text.SimpleDateFormat;

/**
 *
 * @author JOSUE
 */
public class Sobre extends Entregable{
    
    private TipoSobre tipo;
    private boolean contieneDocumento;
    private String contenido;


    public Sobre() {
    }

    public Sobre(TipoSobre tipo, boolean contieneDocumento, String contenido, String numReferencia, boolean estado, String descripcion, 
            String remitente, Calendar fechaEntrega, double peso) {
        
        super(numReferencia, estado, descripcion, remitente, fechaEntrega, peso);
        this.tipo = tipo;
        this.contieneDocumento = contieneDocumento;
        this.contenido = contenido;
    }
    
    

    public TipoSobre getTipo() {
        return tipo;
    }

    public void setTipo(TipoSobre tipo) {
        this.tipo = tipo;
    }

    public boolean isContieneDocumento() {
        return contieneDocumento;
    }

    public void setContieneDocumento(boolean contieneDocumento) {
        this.contieneDocumento = contieneDocumento;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
    

    @Override
    public double calcularImpuesto(){
        
       switch(tipo)
        {
            case Aereo:
                if (contieneDocumento)
                    return 0;

                else 
                    return 1;
        
            case Manila:

                if (contieneDocumento)
                    return 1;

                else 
                    return 2;
                
            default:
                return 0;
        }
        
    }

    @Override
    public String toString() {
        return "Sobre{" + super.toString() + "\n" +
                "tipo=" + tipo + "\n" + 
                ", contenido=" + contenido + '}';
    }
    
    
    
}

