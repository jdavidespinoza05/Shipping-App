/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.List;

/**
 *
 * @author JOSUE
 */
public class Casillero {

    private int numero;
    private boolean estado;
    private Cliente clienteAsignado;

    public Casillero() {

    }

    public Casillero(int numero) {
        this.numero = numero;
    }

    public Casillero(int numero, boolean estado, Cliente clienteAsignado) {
        this.numero = numero;
        this.estado = estado;
        this.clienteAsignado = clienteAsignado;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    public Cliente getClienteAsignado() {
        return clienteAsignado;
    }

    public void setClienteAsignado(Cliente clienteAsignado) {
        this.clienteAsignado = clienteAsignado;
    }
    
    
    public void asignarCliente(Cliente cliente)
    {
        if (!this.estado)
        {
            this.estado = true;
            this.clienteAsignado = cliente;
        }
        
        else
        {
            System.out.println("El casillero ya está ocupado por: " + this.clienteAsignado);
        }
    }
    
    
    public void LiberarCasillero()
    {
        if (this.estado)
        {
            this.clienteAsignado = null;
            this.estado = false;
            
            System.out.println("El casillero " + numero + " ha sido liberado.");
        }
        
        else   
            System.out.println("El casillero " + numero + " está libre.");
    }
    
    public static Casillero casilleroDisponible(List<Casillero> listaCasilleros) {
        for (Casillero casillero : listaCasilleros) {
            if (!casillero.isEstado()) { // Verifica si el casillero está libre
                return casillero; // Retorna el primer casillero disponible
            }
        }
        return null; // Si no hay casilleros disponibles
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Casillero other = (Casillero) obj;
        return this.numero == other.numero;
    }

    @Override
    public String toString() {
        return "Casillero{" + "numero=" + numero + "\n"
                + ", estado=" + estado + "\n"
                + ", clienteAsignado=" + clienteAsignado + '}';
    }

}
