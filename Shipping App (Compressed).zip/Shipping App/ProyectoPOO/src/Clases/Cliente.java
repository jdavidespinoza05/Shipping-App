/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import static Clases.TipoSobre.Aereo;
import static Clases.TipoSobre.Manila;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Pattern;
import javax.swing.*;
import java.awt.*;
import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.util.Properties;

/**
 *
 * @author David
 */
public class Cliente {
    
    private String Id;
    private String nombre;
    private String email;
    private String telefono;
    private String genero;
    private Calendar fechaNacimiento;
    private ArrayList<Entregable> entregables = new ArrayList<Entregable>();
    private Casillero casilleroAsignado;
    private TipoCliente tipoCliente;
    private TipoSobre tipoSobre;
    private double descuento;
    private int nivel;
    private static double totalCobrosColones = 0;
    private static double totalCobrosDolares = 0;


    public Cliente() {
        this.nivel = 1;
        this.tipoCliente = TipoCliente.NORMAL;   
    }

    public Cliente(String Id) {
        this.Id = Id;
        this.nivel = 1;
        this.tipoCliente = TipoCliente.NORMAL;   
    }
    
    public Cliente(String Id, String nombre, String email, String telefono, String genero, Calendar fechaNacimiento) {
        this.Id = Id;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.genero = genero;
        this.fechaNacimiento = fechaNacimiento;
        this.nivel = 1;
        this.tipoCliente = TipoCliente.NORMAL;
        setDescuento();
    }

    public Cliente(String Id, String nombre, String email, String telefono, String genero, Calendar fechaNacimiento, Casillero casilleroAsignado) {
        this.Id = Id;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.genero = genero;
        this.fechaNacimiento = fechaNacimiento;
        this.casilleroAsignado = casilleroAsignado;
        this.nivel = 1;
        this.tipoCliente = TipoCliente.NORMAL;  
        setDescuento();
    }

    public static void agregarCliente(Cliente cliente, ArrayList<Cliente> listaClientes) {
        listaClientes.add(cliente);
    }
    
    
    public static ArrayList<Cliente> getListaClientes(ArrayList<Cliente> listaClientes) {
    return listaClientes;
    }
    
    public ArrayList<Entregable> getEntregables() {
    return entregables;
}

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

        public void setNivel(int nivel){
        this.nivel += nivel;
    }
    
    public int getNivel(){
        return this.nivel;
    }
    
    public TipoCliente getTipoCliente() {
        return tipoCliente;
    }

    private void setTipoCliente(TipoCliente tipoCliente) {
        this.tipoCliente = tipoCliente;
    }


    public void calcularTipoCliente() {
        this.nivel++;
        if (nivel > 3) {
            setTipoCliente(TipoCliente.ORO);
        } else if (nivel > 1) {
            setTipoCliente(TipoCliente.PLATA);
        } else {
            setTipoCliente(TipoCliente.NORMAL);
        }
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Calendar getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Calendar fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public Casillero getCasillero() {
        return casilleroAsignado;
    }

    public void setCasillero(Casillero casilleroAsignado) {
        this.casilleroAsignado = casilleroAsignado;
    }
    
    public static Cliente buscar(String id, ArrayList<Cliente> listaClientes) {
        for (Cliente cliente : listaClientes) {
            if (cliente.Id.equals(id)) {
                return cliente;
            }
        }
        return null; // Retorna null si no se encuentra el cliente
    }
    
    public static Entregable buscarEntregable(String numReferencia, ArrayList <Entregable> entregables){
        for (Entregable entregable : entregables){
            if (entregable.numReferencia.equals(numReferencia)){
                return entregable;
            }  
        }
        return null;// Retorna null si no se encuentra el entregable
    }
    
    
    
    
    
    
    public static void eliminarClienteGUI(ArrayList<Cliente> listaClientes) {
    // Verificar si hay clientes registrados
        if (listaClientes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay clientes registrados.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Salir si no hay clientes
        }

        // Solicitar el ID del cliente a eliminar
        String id = JOptionPane.showInputDialog(null, "Introduce el ID del cliente a eliminar:", "Eliminar Cliente", JOptionPane.QUESTION_MESSAGE);

        // Verificar si se ingresó un ID
        if (id == null || id.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "ID no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Salir del método si el ID es vacío
        }

        // Intentar eliminar el cliente
        boolean eliminado = eliminar(id, listaClientes);

        // Mostrar un mensaje según el resultado de la eliminación
        if (eliminado) {
            JOptionPane.showMessageDialog(null, "Cliente eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Cliente no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    public static boolean eliminar(String id, ArrayList<Cliente> listaClientes) {
        Iterator<Cliente> iterator = listaClientes.iterator();
        while (iterator.hasNext()) {
            Cliente cliente = iterator.next();
            if (cliente.getId().equals(id)) {
                cliente.getCasillero();
                cliente.getCasillero().LiberarCasillero();
                iterator.remove();
                return true; // Cliente eliminado correctamente
            }
        }
        return false; // Cliente no encontrado
    }
    
    public static void consulta(ArrayList<Cliente> listaClientes){
        if (Cliente.getListaClientes(listaClientes).isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay clientes registrados.", "Consulta de Clientes", JOptionPane.INFORMATION_MESSAGE);
            return; // Salir del método si no hay clientes
        }

        // Crear un JFrame para la ventana de consulta
        JFrame consultaFrame = new JFrame("Consulta de Clientes");
        consultaFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cierra solo esta ventana
        consultaFrame.setSize(400, 300); // Tamaño de la ventana

        // Crear un JTextArea para mostrar la lista de clientes
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false); // Hacer que el área de texto no sea editable

        // Agregar los clientes al JTextArea
        StringBuilder sb = new StringBuilder();
        for (Cliente cliente : Cliente.getListaClientes(listaClientes)) {
            sb.append(cliente.toString()).append("\n\n"); // Agregar cada cliente con separación
        }
        textArea.setText(sb.toString());

        // Colocar el JTextArea en un JScrollPane para permitir el desplazamiento
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); // Siempre mostrar barra vertical

        // Agregar el JScrollPane al JFrame
        consultaFrame.add(scrollPane, BorderLayout.CENTER);

        // Hacer visible la ventana
        consultaFrame.setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        consultaFrame.setVisible(true);
    }
    
    public void asignarCasillero(List<Casillero> listaCasilleros) {
        Casillero casilleroLibre = Casillero.casilleroDisponible(listaCasilleros);
        if (casilleroLibre != null) {
            casilleroLibre.asignarCliente(this);
            this.casilleroAsignado = casilleroLibre; // Asigna el casillero al cliente
        } else {
            System.out.println("No hay casilleros disponibles para " + nombre);
        }
    }
    
    public boolean registrar(ArrayList<Cliente> listaClientes){
        System.out.println("holaaaa");
        // ID
        while (true) {
            String inputId = JOptionPane.showInputDialog(null, "Introduce nuevo ID:");
            if (inputId == null) {
                return false; // El usuario canceló
            }
            Id = inputId;

            if (!Id.matches("\\d+")) {
                JOptionPane.showMessageDialog(null, "Entrada inválida. Por favor, introduce solo números.");
            }

            Cliente cliente = buscar(Id, listaClientes);

            if (cliente == null){
                break;
            }else {
                JOptionPane.showMessageDialog(null, "Entrada inválida. El id del cliente ya existe.");  
            }
        }


        // Nombre
        nombre = JOptionPane.showInputDialog(null, "Introduce nuevo Nombre:");
        if (nombre == null) return false; // El usuario canceló

        // Email
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        while (true) {
            String inputEmail = JOptionPane.showInputDialog(null, "Introduce nuevo Email:");
            if (inputEmail == null) {
                return false; // El usuario canceló
            }
            email = inputEmail;

            if (email.matches(emailRegex)) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Entrada inválida. Por favor, introduce un email válido.");
            }
        }

        // Teléfono
        while (true) {
            String inputTelefono = JOptionPane.showInputDialog(null, "Introduce nuevo Teléfono:");
            if (inputTelefono == null) {
                return false; // El usuario canceló
            }
            telefono = inputTelefono;

            if (telefono.matches("\\d{8}")) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Entrada inválida. Por favor, introduce un número de teléfono válido.");
            }
        }

        // Fecha de nacimiento
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        fechaNacimiento = Calendar.getInstance();
        while (true) {
            String fechaInput = JOptionPane.showInputDialog(null, "Introduce fecha de nacimiento (dd/MM/yyyy):");
            if (fechaInput == null) {
                return false; // El usuario canceló
            }
            try {
                java.util.Date fecha = formatoFecha.parse(fechaInput);
                fechaNacimiento.setTime(fecha);
                break;
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(null, "Formato de fecha inválido. Intente de nuevo en el formato correcto.");
            }
        }

        // Género
        String[] ids = {"Hombre", "Mujer", "Otro"};
        String seleccion = (String) JOptionPane.showInputDialog(null, "Selecciona un Género:", "Género", JOptionPane.QUESTION_MESSAGE, null, ids, ids[0]);
        if (seleccion == null) return false; // El usuario canceló
        genero = seleccion;

        // Llama al método para agregar el cliente
        agregarCliente(this, listaClientes);
        return true;
    }

    public static void modificar(ArrayList<Cliente> listaClientes) {
        if (listaClientes.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay clientes registrados.");
            return;
        }
            String id;
            Cliente cliente;
            while (true) {
                id = JOptionPane.showInputDialog(null, "Introduce el ID del cliente a modificar:", "Modificar Cliente", JOptionPane.QUESTION_MESSAGE);
                if (id == null) {
                    return; // El usuario canceló
                }
      
                cliente = buscar(id, listaClientes);
        
                if (cliente == null)
                {
                    JOptionPane.showMessageDialog(null, "Entrada inválida. Cliente no encontrado.");
                    
                }else{
                    break;
                }
            }
        

        JOptionPane.showMessageDialog(null, "Modificar datos del cliente: " + cliente.getNombre());

        // Modificar el nombre
        int opcionNombre = JOptionPane.showConfirmDialog(null, "¿Desea modificar el nombre?", "Modificar Nombre", JOptionPane.YES_NO_OPTION);
        if (opcionNombre == JOptionPane.YES_OPTION) {
            String nuevoNombre = JOptionPane.showInputDialog("Nuevo Nombre (actual: " + cliente.getNombre() + "):");
            if (nuevoNombre == null) return; // Canceló con la X
            if (!nuevoNombre.trim().isEmpty()) {
                cliente.setNombre(nuevoNombre);
            }
        }

        // Modificar el email
        int opcionEmail = JOptionPane.showConfirmDialog(null, "¿Desea modificar el email?", "Modificar Email", JOptionPane.YES_NO_OPTION);
        if (opcionEmail == JOptionPane.YES_OPTION) {
            String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
            while (true) {
                String nuevoEmail = JOptionPane.showInputDialog("Nuevo Email (actual: " + cliente.getEmail() + "):");
                if (nuevoEmail == null) return; // Canceló con la X

                if (nuevoEmail.trim().isEmpty() || Pattern.matches(emailRegex, nuevoEmail)) {
                    cliente.setEmail(nuevoEmail);
                    break; // Salir del bucle si es válido
                } else {
                    JOptionPane.showMessageDialog(null, "Entrada inválida. Por favor, introduce un email válido.");
                }
            }
        }

        // Modificar el teléfono
        int opcionTelefono = JOptionPane.showConfirmDialog(null, "¿Desea modificar el teléfono?", "Modificar Teléfono", JOptionPane.YES_NO_OPTION);
        if (opcionTelefono == JOptionPane.YES_OPTION) {
            while (true) {
                String nuevoTelefono = JOptionPane.showInputDialog("Nuevo Teléfono (actual: " + cliente.getTelefono() + "):");
                if (nuevoTelefono == null) return; // Canceló con la X

                // Validar que el teléfono tenga exactamente 8 caracteres y contenga solo dígitos
                if (nuevoTelefono.matches("\\d{8}")) {
                    cliente.setTelefono(nuevoTelefono); // Asignar el nuevo teléfono
                    break; // Salir del bucle si es válido
                } else {
                    JOptionPane.showMessageDialog(null, "Entrada inválida. Por favor, introduce un número de teléfono de 8 dígitos.");
                }
            }
        }

        JOptionPane.showMessageDialog(null, "Datos del cliente modificados exitosamente.");
    }
    
    

    public void agregarEntregable(ArrayList<Cliente> listaClientes) {
        String id;
        Cliente cliente;
        while (true) {
            id = JOptionPane.showInputDialog(null, "Introduce el ID del cliente:", "Recepcion de articulos", JOptionPane.QUESTION_MESSAGE);
            if (id == null) {
                return; // El usuario canceló
            }

            cliente = buscar(id, listaClientes);

            if (cliente == null) {
                JOptionPane.showMessageDialog(null, "Entrada inválida. Cliente no encontrado.");
            } else {
                break;
            }
        }

        String numReferencia;
        Double peso;

        // numReferencia
        Entregable entregableTemp;
        while (true) {
            String inputNum = JOptionPane.showInputDialog(null, "Introduce el número de referencia:");
            if (inputNum == null) {
                return; // El usuario canceló
            }
            numReferencia = inputNum;

            if (!numReferencia.matches("\\d+")) {
                JOptionPane.showMessageDialog(null, "Entrada inválida. Por favor, introduce solo números.");
                continue; // Volver a solicitar el número
            }

            entregableTemp = buscarEntregable(numReferencia, cliente.entregables);

            if (entregableTemp == null) {
                break;
            } else {
                JOptionPane.showMessageDialog(null, "Entrada inválida. El número de referencia ya existe.");
            }
        }

        // Descripción
        String inputDescripcion;
        while (true) {
            inputDescripcion = JOptionPane.showInputDialog(null, "Introduce la descripción:");
            if (inputDescripcion == null) {
                return; // El usuario canceló
            }
            if (inputDescripcion.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "La descripción no puede estar vacía.");
                continue; // Volver a solicitar la descripción
            }
            break; // Salir del bucle si es válida
        }

        // Remitente
        String inputRemitente;
        while (true) {
            inputRemitente = JOptionPane.showInputDialog(null, "Introduce el remitente:");
            if (inputRemitente == null) {
                return; // El usuario canceló
            }
            if (inputRemitente.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "El remitente no puede estar vacío.");
                continue; // Volver a solicitar el remitente
            }
            break; // Salir del bucle si es válida
        }

        // Peso
        while (true) {
            String inputPeso = JOptionPane.showInputDialog(null, "Introduce el peso:");
            if (inputPeso == null) {
                return; // El usuario canceló
            }

            try {
                peso = Double.parseDouble(inputPeso);
                if (peso <= 0) {
                    JOptionPane.showMessageDialog(null, "El peso debe ser un número positivo.");
                    continue; // Volver a solicitar el peso
                }
                break;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Entrada inválida. Por favor, introduce un número decimal válido.");
            }
        }

        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        Calendar fechaEntrega = Calendar.getInstance();
        while (true) {
            String fechaInput = JOptionPane.showInputDialog(null, "Introduce fecha de entrega (dd/MM/yyyy):");
            if (fechaInput == null) {
                return; // El usuario canceló
            }
            try {
                java.util.Date fecha = formatoFecha.parse(fechaInput);
                fechaEntrega.setTime(fecha);
                break;
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(null, "Formato de fecha inválido. Intente de nuevo en el formato correcto.");
            }
        }

        String subject = "Recepcion de nuevo entregable";
        String body;
        String genero = cliente.getGenero().equals("Mujer") ? "Estimada" : "Estimado";

        // Tipo de entregable
        String[] ids = {"Paquete", "Revista", "Sobre"};
        String seleccion = (String) JOptionPane.showInputDialog(null, "Selecciona el tipo de entregable:", "Entregable", JOptionPane.QUESTION_MESSAGE, null, ids, ids[0]);
        if (seleccion == null) return; // El usuario canceló

        switch (seleccion) {
            case "Paquete":
                Paquete paquete = new Paquete();
                paquete.setNumReferencia(numReferencia);
                paquete.setEstado(true);
                paquete.setDescripcion(inputDescripcion);
                paquete.setRemitente(inputRemitente);
                paquete.setFechaEntrega(fechaEntrega);
                paquete.setPeso(peso);

                int fragil = JOptionPane.showConfirmDialog(null, "El paquete es frágil?", "Paquete", JOptionPane.YES_NO_OPTION);
                paquete.setEsFragil(fragil == JOptionPane.YES_OPTION);

                int peligroso = JOptionPane.showConfirmDialog(null, "El paquete es peligroso?", "Paquete", JOptionPane.YES_NO_OPTION);
                paquete.setEsPeligroso(peligroso == JOptionPane.YES_OPTION);

                int electronico = JOptionPane.showConfirmDialog(null, "El paquete es electrónico?", "Paquete", JOptionPane.YES_NO_OPTION);
                paquete.setEsElectronico(electronico == JOptionPane.YES_OPTION);

                cliente.entregables.add(paquete);
                entregables.add(paquete); // Agregar a la lista de entregables
                body = genero + " " + cliente.getNombre() + "\n\n" + "Se ha recibido un nuevo artículo al casillero " + cliente.casilleroAsignado.getNumero() +
                        " de tipo Paquete." +
                        "\n\nNúmero de referencia " + numReferencia +
                        "\n\nDescripción " + inputDescripcion +
                        ".\n\nGracias,\nServicio de Entregas.";
                cliente.enviarCorreo(subject, body);
                break;

            case "Revista":
                Revista revista = new Revista();
                revista.setNumReferencia(numReferencia);
                revista.setEstado(true);
                revista.setDescripcion(inputDescripcion);
                revista.setRemitente(inputRemitente);
                revista.setFechaEntrega(fechaEntrega);
                revista.setPeso(peso);

                String nombre;
                while (true) {
                    nombre = JOptionPane.showInputDialog(null, "Introduce el nombre:");
                    if (nombre == null) return; // El usuario canceló
                    if (nombre.trim().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "El nombre no puede estar vacío.");
                        continue; // Volver a solicitar el nombre
                    }
                    break; // Salir del bucle si es válido
                }
                revista.setNombre(nombre);

                String tematica;
                while (true) {
                    tematica = JOptionPane.showInputDialog(null, "Introduce la temática:");
                    if (tematica == null) return; // El usuario canceló
                    if (tematica.trim().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "La temática no puede estar vacía.");
                        continue; // Volver a solicitar la temática
                    }
                    break; // Salir del bucle si es válida
                }
                revista.setTematica(tematica);

                int catalogo = JOptionPane.showConfirmDialog(null, "¿Es un catálogo?", "Revista", JOptionPane.YES_NO_OPTION);
                revista.setEsCatalogo(catalogo == JOptionPane.YES_OPTION);

                cliente.entregables.add(revista);
                entregables.add(revista); // Agregar a la lista de entregables
                body = genero + " " + cliente.getNombre() + "\n\n" + "Se ha recibido un nuevo artículo al casillero " + cliente.casilleroAsignado.getNumero() +
                        " de tipo Revista." +
                        "\n\nNúmero de referencia " + numReferencia +
                        "\n\nDescripción " + inputDescripcion +
                        ".\n\nGracias,\nServicio de Entregas.";
                cliente.enviarCorreo(subject, body);
                break;

            case "Sobre":
                Sobre sobre = new Sobre();
                sobre.setNumReferencia(numReferencia);
                sobre.setEstado(true);
                sobre.setDescripcion(inputDescripcion);
                sobre.setRemitente(inputRemitente);
                sobre.setFechaEntrega(fechaEntrega);
                sobre.setPeso(peso);

                int documento = JOptionPane.showConfirmDialog(null, "¿Contiene documento?", "Sobre", JOptionPane.YES_NO_OPTION);
                sobre.setContieneDocumento(documento == JOptionPane.YES_OPTION);

                String contenido;
                while (true) {
                    contenido = JOptionPane.showInputDialog(null, "Introduce el contenido:");
                    if (contenido == null) return; // El usuario canceló
                    if (contenido.trim().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "El contenido no puede estar vacío.");
                        continue; // Volver a solicitar el contenido
                    }
                    break; // Salir del bucle si es válido
                }
                sobre.setContenido(contenido);

                TipoSobre[] ids2 = {TipoSobre.Aereo, TipoSobre.Manila}; // Asegúrate de que tienes definidos los tipos
                TipoSobre tipo = (TipoSobre) JOptionPane.showInputDialog(null, "Selecciona el tipo de sobre:", "Sobre", JOptionPane.QUESTION_MESSAGE, null, ids2, ids2[0]);
                if (tipo == null) return; // El usuario canceló

                sobre.setTipo(tipo);

                cliente.entregables.add(sobre);
                entregables.add(sobre); // Agregar a la lista de entregables
                body = genero + " " + cliente.getNombre() + "\n\n" + "Se ha recibido un nuevo artículo al casillero " + cliente.casilleroAsignado.getNumero() +
                        " de tipo Sobre." +
                        "\n\nNúmero de referencia " + numReferencia +
                        "\n\nDescripción " + inputDescripcion +
                        ".\n\nGracias,\nServicio de Entregas.";
                cliente.enviarCorreo(subject, body);
                break;
        }
    }


public static void consultarEstadoCasillero(ArrayList<Cliente> listaClientes, ArrayList<Casillero> listaCasilleros) {
    String opcion = JOptionPane.showInputDialog(null, "Seleccione el método de búsqueda:\n1. ID Cliente\n2. Número de Casillero", "Consulta de Casillero", JOptionPane.QUESTION_MESSAGE);
    
    if (opcion == null) {
        return; // El usuario canceló
    }
    
    Cliente cliente = null;
    Casillero casillero = null;
    
    if (opcion.equals("1")) {
        String idCliente = JOptionPane.showInputDialog(null, "Introduce el ID del cliente:");
        cliente = buscar(idCliente, listaClientes);
        if (cliente != null) {
            casillero = cliente.getCasillero();
        }
    } else if (opcion.equals("2")) {
        String numCasillero = JOptionPane.showInputDialog(null, "Introduce el número del casillero:");
        try {
            int numeroCasillero = Integer.parseInt(numCasillero.trim());
            casillero = buscarCasillero(numeroCasillero, listaCasilleros);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor ingresa un número válido.");
            return;
        }
    }

    if (casillero != null) {
        // Crear diálogo con área de texto desplazable
        JDialog dialog = new JDialog((Frame)null, "Estado del Casillero", true);
        dialog.setLayout(new BorderLayout());

        // Crear el mensaje del estado del casillero
        StringBuilder mensaje = new StringBuilder();
        mensaje.append("Estado del Casillero:\n\n")
               .append("Número de casillero: ").append(casillero.getNumero()).append("\n")
               .append("Estado: ").append(casillero.isEstado() ? "Ocupado" : "Libre").append("\n\n")
               .append(casillero.toString());

        // Crear área de texto y panel de desplazamiento
        JTextArea textArea = new JTextArea(mensaje.toString());
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 300)); // Tamaño preferido del área con scroll
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        // Botón de OK para cerrar el diálogo
        JButton okButton = new JButton("OK");
        okButton.addActionListener(e -> dialog.dispose());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(okButton);

        // Añadir componentes al diálogo
        dialog.add(scrollPane, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        // Configurar y mostrar el diálogo
        dialog.pack();
        dialog.setLocationRelativeTo(null); // Centrar la ventana
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setVisible(true);
    } else {
        JOptionPane.showMessageDialog(null, "Cliente o casillero no encontrado.");
    }
}


public static Casillero buscarCasillero(int numero, ArrayList<Casillero> listaCasilleros) {
    for (Casillero casillero : listaCasilleros) {
        System.out.println("Buscando casillero: " + casillero.getNumero());
        if (casillero.getNumero() == numero) {
            System.out.println("¡Casillero encontrado!: " + casillero.getNumero());
            return casillero;
        }
    }
    System.out.println("Casillero no encontrado con número: " + numero);
    return null;
}
    
    
public static void consultarDetalleRetiro(ArrayList<Cliente> listaClientes) {
    String id;
    Cliente cliente;

    while (true) {
        id = JOptionPane.showInputDialog(null, "Introduce el ID del cliente:", "Consulta de Detalles de Retiro", JOptionPane.QUESTION_MESSAGE);
        if (id == null) {
            return; // El usuario canceló
        }
        cliente = buscar(id, listaClientes);
        if (cliente == null) {
            JOptionPane.showMessageDialog(null, "Cliente no encontrado.");
        } else {
            break;
        }
    }

    ArrayList<Entregable> entregables = cliente.obtenerEntregables();
    StringBuilder mensaje = new StringBuilder("Detalle del retiro de artículos:\n\n");
    
    for (Entregable entregable : entregables) {
        if (!entregable.isEstado()) { // Artículos ya retirados
            mensaje.append(entregable.toString()).append("\n")
                   .append("Monto cobrado: ").append(entregable.getMontoCobrado()).append("\n")
                   .append("Método de pago: ").append(entregable.getMetodoPago()).append("\n")
                   .append("Impuesto calculado: ").append(entregable.calcularImpuesto()).append("\n\n");
        }
    }

    if (mensaje.length() == 0) {
        mensaje.append("No hay artículos retirados.");
    }

    // Crear diálogo con área de texto desplazable
    JDialog dialog = new JDialog((Frame)null, "Consulta de Detalles de Retiro", true);
    dialog.setLayout(new BorderLayout());

    // Crear área de texto y panel de desplazamiento
    JTextArea textArea = new JTextArea(mensaje.toString());
    textArea.setEditable(false);
    textArea.setLineWrap(true);
    textArea.setWrapStyleWord(true);
    
    JScrollPane scrollPane = new JScrollPane(textArea);
    scrollPane.setPreferredSize(new Dimension(400, 300));  // Tamaño preferido del área con scroll
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

    // Botón de OK para cerrar el diálogo
    JButton okButton = new JButton("OK");
    okButton.addActionListener(e -> dialog.dispose());
    
    JPanel buttonPanel = new JPanel();
    buttonPanel.add(okButton);

    // Añadir componentes al diálogo
    dialog.add(scrollPane, BorderLayout.CENTER);
    dialog.add(buttonPanel, BorderLayout.SOUTH);

    // Configurar y mostrar el diálogo
    dialog.pack();
    dialog.setLocationRelativeTo(null); // Centrar la ventana
    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    dialog.setVisible(true);
}
    
  public static void consultarEntregables(ArrayList<Cliente> listaClientes) {
    String id;
    Cliente cliente;
    while (true) {
        id = JOptionPane.showInputDialog(null, "Introduce el ID del cliente:", "Consulta de Entregables", JOptionPane.QUESTION_MESSAGE);
        if (id == null) {
            return; 
        }
        cliente = buscar(id, listaClientes);
        if (cliente == null) {
            JOptionPane.showMessageDialog(null, "Entrada inválida. Cliente no encontrado.");
        } else {
            break; 
        }
    }
    
    ArrayList<Entregable> entregables = cliente.obtenerEntregables();
   
    if (entregables.isEmpty()) {
        JOptionPane.showMessageDialog(null, "No hay entregables para mostrar.");
        return;
    }
    
    // Create dialog with scrollable text area
    JDialog dialog = new JDialog((Frame)null, "Consulta de Entregables", true);
    dialog.setLayout(new BorderLayout());

    // Build message
    StringBuilder mensaje = new StringBuilder("Entregables del Cliente:\n\n");
    for (int i = 0; i < entregables.size(); i++) {
        mensaje.append(i + 1).append(": ").append(entregables.get(i).toString()).append("\n\n");
    }

    // Create text area and scroll pane
    JTextArea textArea = new JTextArea(mensaje.toString());
    textArea.setEditable(false);
    textArea.setLineWrap(true);
    textArea.setWrapStyleWord(true);
    
    JScrollPane scrollPane = new JScrollPane(textArea);
    scrollPane.setPreferredSize(new Dimension(400, 300));
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

    // Create OK button
    JButton okButton = new JButton("OK");
    okButton.addActionListener(e -> dialog.dispose());
    
    JPanel buttonPanel = new JPanel();
    buttonPanel.add(okButton);

    // Add components to dialog
    dialog.add(scrollPane, BorderLayout.CENTER);
    dialog.add(buttonPanel, BorderLayout.SOUTH);

    // Set up dialog
    dialog.pack();
    dialog.setLocationRelativeTo(null);
    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

    // Show dialog
    dialog.setVisible(true);
}
    
 
        public static void retirarArticulos(ArrayList<Cliente> listaClientes, TipoCambio tipoCambio) { 
        String id;
        Cliente cliente;

    // Obtener ID del cliente
    while (true) {
        id = JOptionPane.showInputDialog(null, "Introduce el ID del cliente:", "Retiro de Artículos", JOptionPane.QUESTION_MESSAGE);
        if (id == null) {
            return; // El usuario canceló
        }

        cliente = buscar(id, listaClientes);
        if (cliente == null) {
            JOptionPane.showMessageDialog(null, "Entrada inválida. Cliente no encontrado.");
        } else {
            break; // Cliente encontrado
        }
    }

    // Obtener entregables pendientes
    ArrayList<Entregable> entregablesPendientes = cliente.obtenerEntregablesPendientes();

    if (entregablesPendientes.isEmpty()) {
        JOptionPane.showMessageDialog(null, "No hay entregables pendientes para retirar.");
        return;
    }

    // Create dialog components
    JDialog dialog = new JDialog((Frame)null, "Retiro de Artículos", true);
    dialog.setLayout(new BorderLayout());

    // Create the text area with the list of deliverables
    StringBuilder mensaje = new StringBuilder("Selecciona el entregable a retirar:\n\n");
    for (int i = 0; i < entregablesPendientes.size(); i++) {
        mensaje.append(i + 1).append(": ").append(entregablesPendientes.get(i).toString()).append("\n\n");
    }

    JTextArea textArea = new JTextArea(mensaje.toString());
    textArea.setEditable(false);
    textArea.setLineWrap(true);
    textArea.setWrapStyleWord(true);
    
    // Create scroll pane and set preferred size
    JScrollPane scrollPane = new JScrollPane(textArea);
    scrollPane.setPreferredSize(new Dimension(400, 300));
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

    // Create input panel
    JPanel inputPanel = new JPanel(new FlowLayout());
    JTextField inputField = new JTextField(20);
    inputPanel.add(new JLabel("Ingresa el índice del entregable:"));
    inputPanel.add(inputField);

    // Create buttons panel
    JPanel buttonPanel = new JPanel();
    JButton okButton = new JButton("Aceptar");
    JButton cancelButton = new JButton("Cancelar");
    buttonPanel.add(okButton);
    buttonPanel.add(cancelButton);

    // Add components to dialog
    dialog.add(scrollPane, BorderLayout.CENTER);
    dialog.add(inputPanel, BorderLayout.NORTH);
    dialog.add(buttonPanel, BorderLayout.SOUTH);

    // Set up dialog properties
    dialog.pack();
    dialog.setLocationRelativeTo(null);
    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

    // Reference to store user input
    final String[] userInput = {null};

    // Add action listeners
    okButton.addActionListener(e -> {
        userInput[0] = inputField.getText();
        dialog.dispose();
    });
    
    cancelButton.addActionListener(e -> dialog.dispose());

    // Show dialog and wait for user input
    dialog.setVisible(true);

    // Process user input after dialog is closed
    if (userInput[0] == null || userInput[0].isEmpty()) {
        return; // User cancelled or provided no input
    }

    String[] indices = userInput[0].split(",");
    List<Entregable> entregablesSeleccionados = new ArrayList<>();
    for (String indice : indices) {
        try {
            int index = Integer.parseInt(indice.trim()) - 1; // Adjust to 0 index
            if (index >= 0 && index < entregablesPendientes.size()) {
                entregablesSeleccionados.add(entregablesPendientes.get(index));
            } else {
                JOptionPane.showMessageDialog(null, "Índice inválido: " + (index + 1));
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Entrada no válida: " + indice);
            return;
        }
    }

    // Calculate the total taxes
    double totalImpuestoColones = 0;
    double totalImpuestoDolares = 0;
    double descuento = 1 - cliente.getDescuento();

    for (Entregable entregable : entregablesSeleccionados) {
        if (entregable instanceof Sobre) {
            // Lógica específica para sobres
            Sobre sobre = (Sobre) entregable;
            totalImpuestoDolares += sobre.calcularImpuesto()* descuento;
        } else if (entregable instanceof Paquete) {
            // Lógica específica para paquetes
            Paquete paquete = (Paquete) entregable;
            totalImpuestoDolares += paquete.calcularImpuesto()* descuento;
        } else if (entregable instanceof Revista) {
            // Lógica específica para revistas
            Revista revista = (Revista) entregable;
            totalImpuestoDolares += revista.calcularImpuesto()* descuento;
        }
    }

    // Conversion of total to dollars
    double tipoCambioCompra = tipoCambio.consulta()[0]; // Get purchase exchange rate
    totalImpuestoColones = totalImpuestoDolares * tipoCambioCompra;

    // Ask for the payment method before processing the selected items
    String mensajeFinal = String.format("Total a pagar en colones: %.2f\nTotal a pagar en dólares: %.2f\nTipo de cambio usado (compra): %.2f", 
                                         totalImpuestoColones, totalImpuestoDolares, tipoCambioCompra);

    mensajeFinal += "\n\n¿Desea pagar con tarjeta (Sí) o en efectivo (No)?";
    int respuesta = JOptionPane.showConfirmDialog(null, mensajeFinal, "Método de pago", JOptionPane.YES_NO_OPTION);

    String metodoPago;
    cliente.calcularTipoCliente();
    if (respuesta == JOptionPane.YES_OPTION) {
        metodoPago = "Tarjeta";
        JOptionPane.showMessageDialog(null, "Pago realizado con tarjeta.");
    } else if (respuesta == JOptionPane.NO_OPTION) {
        metodoPago = "Contado";
        JOptionPane.showMessageDialog(null, "Pago realizado en efectivo.");
    } else {
        return; // User cancelled
    }

    // Process the withdrawal of the selected items and apply the payment method
    for (Entregable entregable : entregablesSeleccionados) {
        // Change the status to withdrawn
        entregable.setEstado(false);
        System.out.println("Monto a cobrar: " + totalImpuestoDolares);
        if (entregable != null) {
            entregable.setMontoCobrado(totalImpuestoDolares);
        } else {
            System.out.println("El entregable es null");
        }
        entregable.setMetodoPago(metodoPago);
        // Mark the withdrawal date and time
        entregable.setFechaEntrega(Calendar.getInstance());

        System.out.println("Ha retirado el siguiente entregable:");
        System.out.println(entregable);
        
        // Uncomment if you need to handle lockers
        // Casillero casillero = entregable.getCasillero(); 
        // if (casillero != null) {
        //     casillero.LiberarCasillero();
        // }
    }

        JOptionPane.showMessageDialog(null, "Retiro realizado exitosamente.");
        agregarCobro(totalImpuestoColones, totalImpuestoDolares);
    }
    
    public static void agregarCobro(double montoColones, double montoDolares) {
        totalCobrosColones += montoColones;
        totalCobrosDolares += montoDolares;
    }
    
    
    public double getDescuento() {
        return descuento;
    }

    public void setDescuento() {
    switch (tipoCliente) {
        case NORMAL:
            this.descuento = 0.0;
            break;
        case PLATA:
            this.descuento = 0.05;
            break;
        case ORO:
            this.descuento = 0.10;
            break;
    }
}
    
    public ArrayList<Entregable> obtenerEntregablesPendientes() {
        ArrayList<Entregable> entregablesPendientes = new ArrayList<>();
        for (Entregable entregable : entregables) {
            if (entregable.isEstado()) { 
                entregablesPendientes.add(entregable);
            }
        }
        return entregablesPendientes;
    }
    
    public ArrayList<Entregable> obtenerEntregables() {
        return entregables; 
    }
    
    
    public void enviarCorreo(String subject, String body) 
    {
        String to = this.email; // Correo del cliente
        String from = "proyectopoo56@gmail.com"; // Cambia esto por tu dirección de correo
        String password = "cobptahidrlgwrnl"; // Cambia esto por tu contraseña

        // Configuración de propiedades
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com"); // Cambia esto si usas otro proveedor
        properties.put("mail.smtp.user", from);
        properties.put("mail.smtp.clave", password);
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.ssl.protocols", "TLSv1.2");
        

        // Crear sesión
        Session session = Session.getDefaultInstance(properties);
        MimeMessage message = new MimeMessage(session);

        try {
            // Crear el mensaje
            message.setFrom(new InternetAddress(from));
            //message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to)); 
            message.setSubject(subject);
            message.setText(body);

            // Enviar el mensaje
            Transport transport = session.getTransport("smtp");
            transport.connect("smtp.gmail.com", from, password);
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();
            //Transport.send(message);
            System.out.println("Correo enviado exitosamente a " + to);
        } 
        
        catch (MessagingException e) {
            System.err.println("Error al enviar el correo " + e.getMessage());
            e.printStackTrace();
        }
    }

    
    
        public void mostrarEntregablesPorFecha() {
        // Pedir al usuario que introduzca una fecha
        String inputFecha = JOptionPane.showInputDialog("Introduce una fecha (dd/MM/yy):");
        if (inputFecha == null) return; // El usuario canceló

        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yy");
        Calendar fechaBuscada = Calendar.getInstance();
        
        try {
            // Parsear la fecha introducida por el usuario
            fechaBuscada.setTime(formatoFecha.parse(inputFecha));
            fechaBuscada.set(Calendar.HOUR_OF_DAY, 0);
            fechaBuscada.set(Calendar.MINUTE, 0);
            fechaBuscada.set(Calendar.SECOND, 0);
            fechaBuscada.set(Calendar.MILLISECOND, 0);

            boolean encontrado = false;

            // Filtrar y mostrar entregables
            for (Entregable entregable : entregables) {
                Calendar fechaInsercion = entregable.getFechaInsercion(); // Supongo que tienes este método en Entregable
                if (fechaInsercion.get(Calendar.YEAR) == fechaBuscada.get(Calendar.YEAR) &&
                    fechaInsercion.get(Calendar.MONTH) == fechaBuscada.get(Calendar.MONTH) &&
                    fechaInsercion.get(Calendar.DAY_OF_MONTH) == fechaBuscada.get(Calendar.DAY_OF_MONTH)) {
                    
                    System.out.println(entregable.toString()); // Asegúrate de que Entregable tenga un método toString()
                    encontrado = true;
                }
            }

            if (!encontrado) {
                JOptionPane.showMessageDialog(null, "No se encontraron entregables para la fecha: " + inputFecha);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Fecha inválida. Por favor, utiliza el formato dd/MM/yy.");
        }
    }
    
    public void buscarEntregablesPorFecha(Calendar fechaBuscada) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        boolean encontrado = false;

        // Recorrer la lista de entregables del cliente
        for (Entregable entregable : entregables) {
            // Comparar las fechas
            if (isSameDay(entregable.getFechaInsercion(), fechaBuscada)) {
                // Si coinciden, mostrar los detalles del entregable
                JOptionPane.showMessageDialog(null, entregable.toString(), 
                                              "Entregable encontrado", 
                                              JOptionPane.INFORMATION_MESSAGE);
                encontrado = true;
            }
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(null, "No se encontraron entregables para la fecha: " + formatoFecha.format(fechaBuscada.getTime()));
        }
    }
    
   
   public void buscarPaquetesRetiradosPorFecha(Calendar fechaBuscada) {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
       boolean encontrado = false;

       // Recorrer la lista de entregables del cliente
       for (Entregable entregable : entregables) {
           // Comparar las fechas
           if (isSameDay(entregable.getFechaEntrega(), fechaBuscada)) {
               // Si coinciden, mostrar los detalles del entregable
               JOptionPane.showMessageDialog(null, entregable.toString(), 
                                             "Entregable encontrado", 
                                             JOptionPane.INFORMATION_MESSAGE);
               encontrado = true;
           }
       }

       if (!encontrado) {
           JOptionPane.showMessageDialog(null, "No se encontraron entregables retirados en la fecha: " + formatoFecha.format(fechaBuscada.getTime()));
       }
}



    // Método auxiliar para comparar fechas
    private boolean isSameDay(Calendar fecha1, Calendar fecha2) {
        return fecha1.get(Calendar.YEAR) == fecha2.get(Calendar.YEAR) &&
               fecha1.get(Calendar.DAY_OF_YEAR) == fecha2.get(Calendar.DAY_OF_YEAR);
    }

    public static void ClientesPaquetesPendientes(ArrayList<Cliente> listaClientes){
        
        if (Cliente.getListaClientes(listaClientes).isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay clientes registrados.", "Lista Clientes", JOptionPane.INFORMATION_MESSAGE);
            return; // Salir del método si no hay clientes
        }
        // Crear un JFrame para la ventana de consulta
        JFrame consultaFrame = new JFrame("Clientes\n\n");
        consultaFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cierra solo esta ventana
        consultaFrame.setSize(400, 300); // Tamaño de la ventana

        // Crear un JTextArea para mostrar la lista de clientes
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false); // Hacer que el área de texto no sea editable

        // Agregar los clientes al JTextArea
        StringBuilder sb = new StringBuilder();
        int pendientes;
        boolean lista = false;
        
        for (Cliente cliente : Cliente.getListaClientes(listaClientes)) {
            pendientes = 0;
            ArrayList<Entregable> entregables = cliente.obtenerEntregables();
            if (!entregables.isEmpty()) {
                for (Entregable entregable : entregables) {
                    if(entregable.isEstado()){
                        pendientes++;
                    }
                }
                if (pendientes > 0){
                    sb.append("ID: ").append(cliente.Id).append("\n").append("Nombre: ").append(cliente.nombre)
                      .append("\n").append("Teléfono: ").append(cliente.telefono).append("\n")   
                      .append("Correo: ").append(cliente.email).append("\n")
                      .append("Cantidad de paquetes pendientes: ").append(pendientes).append("\n\n"); // Agregar cada cliente con separación
                    lista = true;
                }
            }
        }
        
        if (!lista){
            JOptionPane.showMessageDialog(null, "No hay clientes con entregables pendientes.", "Lista Clientes", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
            
        textArea.setText(sb.toString());

        // Colocar el JTextArea en un JScrollPane para permitir el desplazamiento
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); // Siempre mostrar barra vertical

        // Agregar el JScrollPane al JFrame
        consultaFrame.add(scrollPane, BorderLayout.CENTER);

        // Hacer visible la ventana
        consultaFrame.setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        consultaFrame.setVisible(true);
    }
    
    
    public static void ConsultaArticulosP(ArrayList<Cliente> listaClientes){
        String id;
        Cliente cliente;
        while (true) {
            id = JOptionPane.showInputDialog(null, "Introduce el ID del cliente:", "Artículos pendientes", JOptionPane.QUESTION_MESSAGE);
            if (id == null) {
                return; // El usuario canceló
            }

            cliente = buscar(id, listaClientes);

            if (cliente == null) {
                JOptionPane.showMessageDialog(null, "Entrada inválida. Cliente no encontrado.");
            } else {
                break;
            }
        }
        
        // Crear un JFrame para la ventana de consulta
        JFrame consultaFrame = new JFrame("Artículos pedientes\n\n");
        consultaFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cierra solo esta ventana
        consultaFrame.setSize(400, 300); // Tamaño de la ventana

        // Crear un JTextArea para mostrar la lista de clientes
        JTextArea textArea = new JTextArea();
        textArea.setEditable(false); // Hacer que el área de texto no sea editable

        // Agregar los clientes al JTextArea
        StringBuilder sb = new StringBuilder();
        boolean lista = false;
        int cont = 0;
        
        ArrayList<Entregable> entregables = cliente.obtenerEntregables();
        if (!entregables.isEmpty()) {
            for (Entregable entregable : entregables) {
                if(entregable.isEstado()){
                    sb.append(entregable.toString()).append("\n\n");
                    cont ++;
                    lista = true;
                }
            }
        }
        
        if (!lista){
            JOptionPane.showMessageDialog(null, "No hay artículos pendientes.", "Artículos pendientes", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        
        textArea.setText(sb.toString());

        // Colocar el JTextArea en un JScrollPane para permitir el desplazamiento
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); // Siempre mostrar barra vertical

        // Agregar el JScrollPane al JFrame
        consultaFrame.add(scrollPane, BorderLayout.CENTER);

        // Hacer visible la ventana
        consultaFrame.setLocationRelativeTo(null); // Centrar la ventana en la pantalla
        consultaFrame.setVisible(true);
        
        int respuesta = JOptionPane.showConfirmDialog(null, "Desea enviar correo con la información", "Enviar correo", JOptionPane.YES_NO_OPTION);
        
        if (respuesta == JOptionPane.YES_OPTION) {
            String subject = "Artítulos pendientes de retirar";
            String genero = cliente.getGenero().equals("Mujer") ? "Estimada" : "Estimado";
            String body = genero + " " + cliente.getNombre() + "\n\n" + "Se le informa que su casillero: " + cliente.casilleroAsignado.getNumero() +
                        " tiene un total de: " + cont + " artículos pendientes de retirar." +
                        ".\n\nGracias,\nServicio de Entregas.";
            cliente.enviarCorreo(subject, body);
            JOptionPane.showMessageDialog(null, "Correo enviado exitosamente.");
                
        } else {
            return; // User cancelled
        }
    }

    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cliente other = (Cliente) obj;
        return Objects.equals(this.Id, other.Id);
    }

    @Override
    public String toString() { 
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        String fechaFormatted = (fechaNacimiento != null) ? formatoFecha.format(fechaNacimiento.getTime()) : "No disponible";

        String casilleroInfo;
        try {
            casilleroInfo = String.valueOf(casilleroAsignado.getNumero());
        } catch (NullPointerException e) {
            casilleroInfo = "Sin casillero"; // Si casilleroAsignado es null
        } catch (Exception e) {
            casilleroInfo = "Error al obtener casillero"; // Para cualquier otro tipo de excepción
        }

        return String.format("Cliente {\n" +
            "  Id: %s\n" +
            "  Nombre: %s\n" +
            "  Email: %s\n" +
            "  Teléfono: %s\n" +
            "  TipoCliente %s\n" +
            "  Género: %s\n" +
            "  Fecha de Nacimiento: %s\n" +
            "  Casillero: %s\n" +
            "  Entregables: %s\n" +
            "}", 
            Id, 
            nombre, 
            email, 
            telefono, 
            tipoCliente,
            genero, 
            fechaFormatted, 
            casilleroInfo, // Usa la variable casilleroInfo
            entregables.toString());
        }
    }

